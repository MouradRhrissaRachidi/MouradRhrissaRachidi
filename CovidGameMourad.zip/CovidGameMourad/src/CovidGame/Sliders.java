package CovidGame;
import java.awt.*;
import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class Sliders extends JPanel implements DatosGenerales {
	//JPanel crear un nuevo panel
		private JPanel controls;
		//JLabel para crear las etiquetas
		private JLabel rLabel, gLabel, bLabel;
		
		public Sliders() {
			//La  mayor marca de graduaci�n, ser� representada cada 5 marcas 
			bSlider.setMajorTickSpacing(5);
			//La menor marca de graduaci�n, ser� representada cada 1 marca 
			bSlider.setMinorTickSpacing(1);
			//mostrar las marcas de graduaci�n
			bSlider.setPaintTicks(true);
			//mostrar los n�meros de las marcas de graduaci�n, en nuestro caso se mostrar� 0-5-10
			bSlider.setPaintLabels(true);
			//alineaci�n a la izquierda de nuestro slider
			bSlider.setAlignmentX(Component.LEFT_ALIGNMENT);
		
			rSlider.setMajorTickSpacing(5);
			rSlider.setMinorTickSpacing(1);
			rSlider.setPaintTicks(true);
			rSlider.setPaintLabels(true);
			rSlider.setAlignmentX(Component.LEFT_ALIGNMENT);
			
			gSlider.setMajorTickSpacing(5);
			gSlider.setMinorTickSpacing(1);
			gSlider.setPaintTicks(true);
			gSlider.setPaintLabels(true);
			gSlider.setAlignmentX(Component.LEFT_ALIGNMENT);
			
			//creamos los escuchantes 
			
			SliderListener1 listener1 = new SliderListener1();
			SliderListener2 listener2 = new SliderListener2();
			SliderListener3 listener3= new SliderListener3();
			
			//a�adimos los escuchantes
			
			bSlider.addChangeListener(listener1);
			gSlider.addChangeListener(listener2);
			rSlider.addChangeListener(listener3);
			
			bLabel = new JLabel("covidArriba: 0");
			bLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
			gLabel = new JLabel("covidMedio: 0");
			gLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
			rLabel = new JLabel("covidAbajo: 0");
			rLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
			
			//Creamos el panel y a�adimos los componentes
			
			controls = new JPanel();
			BoxLayout layout = new BoxLayout(controls,BoxLayout.Y_AXIS);
			controls.setLayout(layout);
			controls.add(bLabel);
			controls.add(bSlider);
			controls.add(Box.createRigidArea(new Dimension(0,10)));
			controls.add(gLabel);
			controls.add(gSlider);
			controls.add(Box.createRigidArea(new Dimension(0,10)));
			controls.add(rLabel);
			controls.add(rSlider);
			add(controls);
		}
		//creamos una clase privada con la inteface changeListener para recibir notificaciones cuando cambia el valor de los covids
		private class SliderListener1 implements ChangeListener{
			private double covidArriba;
			public void stateChanged(ChangeEvent event){
				covidArriba= covs.valormas1();
				bLabel.setText("covidArriba: " + bSlider.getValue());
			}
		}
		private class SliderListener2 implements ChangeListener{
			private double covidMedio;
			public void stateChanged(ChangeEvent event){
				covidMedio=covs.valormas2();
				gLabel.setText("covidMedio: "+gSlider.getValue());
			}
		}
		private class SliderListener3 implements ChangeListener{
			private double covidAbajo;
			public void stateChanged(ChangeEvent event){
				covidAbajo = covs.valormas3();
				rLabel.setText("covidAbajo: " + rSlider.getValue());
			}
		}
		
		
	}