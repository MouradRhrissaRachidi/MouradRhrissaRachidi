package CovidGame;

import java.awt.*;
import java.awt.event.FocusListener;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
public class principal extends JFrame{
public static void main(String []args) {  
	JOptionPane.showMessageDialog(null,"           �Est�s listo?");
	//creamos el marco
	ventanitas ventana=new ventanitas();
	ventana.setTitle("CovidGame");
	//Para que el usuario no agrande el tama�o del frame
	ventana.setResizable(false);
	//hacer visible el marco
	ventana.setVisible(true);
	//tama�o del marco
	ventana.setSize(600,700);
	//centrar el frame
	ventana.setLocationRelativeTo(null);
	//cu�ndo el usuario pulse el bot�n de cerrar se cierre el juego
	ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	//bucle while nos permitir� el repintado del programa
	while(true) {
		//repaint produce el repintado
		ventana.repaint();
		try {
			//Thread.sleep sirve para que no se produzca el repitando o rec�lculo hasta despu�s de transcurrido 10 milisegundos
			Thread.sleep(10);
			//en caso de que se produza un error de este bucle saltar� una excepci�n del tipo InterruptedException
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	}

}
class ventanitas extends JFrame{
	public ventanitas() {
		//Creo el conjunto de pesta�as
		JTabbedPane pesta�as=new JTabbedPane();
		setVisible(true);
		//creamos primer panel
	    juego panel1=new juego();
	    //a�adimos el panel al conjunto de pesta�as
	    pesta�as.addTab("Juego", panel1);
	    //creamos el segundo panel
		Sliders panel2=new Sliders();
		//a�dimos el panel al conjunto de pesta�as
		pesta�as.addTab("Sliders", panel2);
		//a�adimos un marco en otro marco
		getContentPane().add(pesta�as);
	   
	}
}
	

	
