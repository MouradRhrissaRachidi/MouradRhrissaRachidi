 package CovidGame;

import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.*;

public class covids implements DatosGenerales  {
	//creamos una lista de covids de clase DatosCovids con la clase ArrayList
	private static ArrayList<DatosCovids> dato =new ArrayList<DatosCovids>();
	//creamos variable de tipo imagen
	private Image imagen;
	private double moveX1,moveX2,moveX3;
	juego jueguito;
	DatosCovids covid1=new DatosCovids(500,60,0,0);
	DatosCovids covid2=new DatosCovids(200,270,0,0);
	DatosCovids covid3=new DatosCovids(300,520,0,0);
public covids() {
	//la clase File direcci�n donde se encuentra la im�gen
	File miimagen =new File("src/covid.png");
	try {
		// Image IO=para rescatar im�genes que se encuentran fuera de nuestro programa
	imagen=ImageIO.read(miimagen);
	}
	//si ImageIO no pudo rescatar la im�gen, entonces saltar� una excepci�n del tipo IOException
	catch(IOException e) {
		System.out.println("No se encontr� la imagen covid.png ");
}
	dato.add(covid1);
	dato.add(covid2);
	dato.add(covid3);
	moveX1=1.5;
	moveX2=2;
	moveX3=2.5;
	
}
public void setX1(int x) {
	covid1.x=x;
}
public void setX2(int x) {
	covid2.x=x;
}
public void setX3(int x) {
	covid3.x=x;
}
public void setY1(int y) {
	covid1.y=y;
}
public void setY2(int y) {
	covid2.y=y;
}
public void setY3(int y) {
	covid3.y=y;
}
//m�todo que nos permite dibujar la im�gen
protected void paint(Graphics2D g) {
	for(DatosCovids a: dato) {
	g.drawImage(imagen,a.getX(),a.getY(),null);
	}
}
//para el movimiento de los covids
public void moverCovids() {
		covid1.x+=moveX1;
		if(covid1.x<0|covid1.x>=580-imagen.getWidth(jueguito)) {
			moveX1=moveX1*-1;
		}
		covid2.x+=moveX2;
		if(covid2.x<0|covid2.x>=580-imagen.getWidth(jueguito)) {
			moveX2=moveX2*-1;
		}
		covid3.x+=moveX3;
		if(covid3.x<0|covid3.x>=580-imagen.getWidth(jueguito)) {
			moveX3=moveX3*-1;
		}
		
}
//cu�ndo se produzca un cambio de valor en los sliders, el covid coger� otra velocidades gracias a este m�todo
public double valormas1() {
	if(bSlider.getValue()==1) {
		moveX1=2;
	}
	if(bSlider.getValue()==2) {
		moveX1=2.5;
	}
	if(bSlider.getValue()==3) {
		moveX1=3;
	}
	if(bSlider.getValue()==4) {
		moveX1=3.5;
	}
	if(bSlider.getValue()==5) {
		moveX1=4;
	}
	if(bSlider.getValue()==6) {
		moveX1=4.5;
	}
	if(bSlider.getValue()==7) {
		moveX1=5;
	}
	if(bSlider.getValue()==8) {
		moveX1=5.5;
	}
	if(bSlider.getValue()==9) {
		moveX1=6;
	}
	if(bSlider.getValue()==10) {
		moveX1=6.5;
	}
	
	return moveX1;
}

public double valormas2() {
	if(gSlider.getValue()==1) {
		moveX2=2.5;
	}
	if(gSlider.getValue()==2) {
		moveX2=3;
	}
	if(gSlider.getValue()==3) {
		moveX2=3.5;
	}
	if(gSlider.getValue()==4) {
		moveX2=4;
	}
	if(gSlider.getValue()==5) {
		moveX2=4.5;
	}
	if(gSlider.getValue()==6) {
		moveX2=5;
	}
	if(gSlider.getValue()==7) {
		moveX2=5.5;
	}
	if(gSlider.getValue()==8) {
		moveX2=6;
	}
	if(gSlider.getValue()==9) {
		moveX2=6.5;
	}
	if(gSlider.getValue()==10) {
		moveX2=7;
	}
	
	return moveX2;
	
}
public double valormas3() {
	if(rSlider.getValue()==1) {
		moveX3=3;
	}
	if(rSlider.getValue()==2) {
		moveX3=3.5;
	}
	if(rSlider.getValue()==3) {
		moveX3=4;
	}
	if(rSlider.getValue()==4) {
		moveX3=4.5;
	}
	if(rSlider.getValue()==5) {
		moveX3=5;
	}
	if(rSlider.getValue()==6) {
		moveX3=5.5;
	}
	if(rSlider.getValue()==7) {
		moveX3=6;
	}
	if(rSlider.getValue()==8) {
		moveX3=6.5;
	}
	if(rSlider.getValue()==9) {
		moveX3=7;
	}
	if(rSlider.getValue()==10) {
		moveX3=7.5;
	}
	
	return moveX3;
}
//Creamos un rect�ngulo con las medidas de cada covid
public Rectangle getBoundsCovids3() {
	return new Rectangle(covid3.x,covid3.y,imagen.getWidth(null),imagen.getHeight(null));
	}
public Rectangle getBoundsCovids2() {
	return new Rectangle(covid2.x,covid2.y,imagen.getWidth(null),imagen.getHeight(null));
	}
public Rectangle getBoundsCovids1() {
	return new Rectangle(covid1.x,covid1.y,imagen.getWidth(null),imagen.getHeight(null));
	}
}
