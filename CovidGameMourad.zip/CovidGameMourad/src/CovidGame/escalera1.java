package CovidGame;

import java.awt.*;
import java.io.*;
import javax.imageio.*;
import javax.swing.*;

public class escalera1 extends JPanel{
	//creamos variable de tipo imagen
		private Image imagen;
		private int x,y;
	public escalera1() {
		//la clase File direcci�n donde se encuentra la im�gen
		File miimagen =new File("src/escalera1.png");
		try {
			// Image IO=para rescatar im�genes que se encuentran fuera de nuestro programa
		imagen=ImageIO.read(miimagen);
		}
		//si ImageIO no pudo rescatar la im�gen, entonces saltar� una excepci�n del tipo IOException
		catch(IOException e) {
			System.out.println("No se encontr� la imagen escalera1.png");
		}
		x=100;
		y=137;
	}
	//m�todo que nos permite dibujar la im�gen
	public void paint(Graphics2D g) {
		super.paintComponents(g);
		g.drawImage(imagen,x,y,null);
		}
	//Creamos un rect�ngulo con las medidas de la escalera
	public Rectangle getBoundsEscalera1() {
		return new Rectangle(x,y,imagen.getWidth(null),imagen.getHeight(null));
	}
	
}


