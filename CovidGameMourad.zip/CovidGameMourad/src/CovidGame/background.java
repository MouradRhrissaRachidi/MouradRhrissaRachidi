package CovidGame;

import java.awt.*;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.*;

public class background extends JPanel {
	//creamos variable de tipo imagen
	private Image imagen;
public background() {
	//la clase File direcci�n donde se encuentra la im�gen
	File miimagen =new File("src/background.png");
	try {
		// Image IO=para rescatar im�genes que se encuentran fuera de nuestro programa
	imagen=ImageIO.read(miimagen);
	}
	//si ImageIO no pudo rescatar la im�gen, entonces saltar� una excepci�n del tipo IOException
	catch(IOException e) {
		System.out.println("No se encontr� la imagen background.png ");
	}
}
//m�todo que nos permite dibujar la im�gen
	public void paint(Graphics2D g) {
		super.paintComponents(g);
		g.drawImage(imagen,-40,-40,null);
	
	}
}