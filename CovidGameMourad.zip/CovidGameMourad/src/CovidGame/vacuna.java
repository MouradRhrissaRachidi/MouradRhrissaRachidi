package CovidGame;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JPanel;

public class vacuna extends JPanel{
	//creamos variable de tipo imagen
		private Image imagen;
		private int x,y;
		
	public vacuna() {
		//la clase File direcci�n donde se encuentra la im�gen
		File miimagen =new File("src/vacuna.png");
		try {
			// Image IO=para rescatar im�genes que se encuentran fuera de nuestro programa
		imagen=ImageIO.read(miimagen);
		}
		//si ImageIO no pudo rescatar la im�gen, entonces saltar� una excepci�n del tipo IOException
		catch(IOException e) {
			System.out.println("No se encontr� la imagen vacuna.png");
		}
		x=200;
		y=100;
	}
	//m�todo que nos permite dibujar la im�gen
	public void paint(Graphics2D g) {
		super.paintComponents(g);
		g.drawImage(imagen,x,y,null);
		}
	//Creamos un rect�ngulo con las medidas de la vacuna
	public Rectangle getBoundsVacuna() {
		return new Rectangle(x,y,imagen.getWidth(null),imagen.getHeight(null));
	}
}