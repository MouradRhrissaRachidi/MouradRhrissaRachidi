package CovidGame;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class juego extends JPanel implements ActionListener
,DatosGenerales{
	//El timer que nos permite dibujar el juego cada 5 milisegundos
	Timer timer=new Timer(5,this);
	
public juego() {
	addKeyListener(new teclado());
	//setFocusable con la opci�n true nos permite activar el evento de teclado
	setFocusable(true);
	timer.start();
}	
//m�todo para dibujar todas las im�genes que nos har�n falta para nuestro programa
public void paintComponent(Graphics g) {
	super.paintComponents(g);
	Graphics2D g2=(Graphics2D)g;
	dibujar(g2);
}
//m�todo para dibujar todas las im�genes que nos har�n falta para nuestro programa
public void dibujar(Graphics2D g) {
	fondo.paint(g);
	covs.paint(g);
	pro.paint(g);
	esc1.paint(g);
	esc2.paint(g);
	vac.paint(g);
	}

//Con el metodo actionPerformed detectamos y manejamos con el eventos
public void actionPerformed(ActionEvent e) {
	pro.mover();
	covs.moverCovids();
	//creamos los rect�ngulos, invocanco sus respectivos m�todos para saber cu�ndo intersecta
	Rectangle player=pro.getBoundsProtagonista();
	Rectangle cov3=covs.getBoundsCovids3();
	Rectangle cov2=covs.getBoundsCovids2();
	Rectangle cov1=covs.getBoundsCovids1();
	Rectangle vacuna=vac.getBoundsVacuna();
	if(player.intersects(cov3)||player.intersects(cov2)||player.intersects(cov1)){
		//mostrar el mensaje cuando intersecten
		JOptionPane.showMessageDialog(this, "Game Over", "Game Over", JOptionPane.YES_NO_OPTION);
		int g =JOptionPane.showConfirmDialog(null, "�Quieres jugar otra partida?","Elige",JOptionPane.YES_NO_CANCEL_OPTION,JOptionPane.QUESTION_MESSAGE);
		if(g==JOptionPane.YES_OPTION) {
			covs.setX1(500);
			covs.setX2(200);
			covs.setX3(500);
			covs.setY1(60);
			covs.setY2(270);
			covs.setY3(520);
			pro.setX(5);
			pro.setY(492);
			pro.dejardeMover();
		}
		if(g==JOptionPane.NO_OPTION) {
			//para cerrar el juego
			System.exit(ABORT);
		}
		if(g==JOptionPane.CANCEL_OPTION) {
			System.exit(ABORT);
		}
	}

	if(player.intersects(vacuna)){
		JOptionPane.showMessageDialog(this, "Win", "Win",JOptionPane.INFORMATION_MESSAGE);
		int g =JOptionPane.showConfirmDialog(null, "�Quieres jugar otra partida?","Elige",JOptionPane.YES_NO_CANCEL_OPTION,JOptionPane.QUESTION_MESSAGE);
		if(g==JOptionPane.YES_OPTION) {
			covs.setX1(500);
			covs.setX2(200);
			covs.setX3(500);
			covs.setY1(60);
			covs.setY2(270);
			covs.setY3(520);
			pro.setX(5);
			pro.setY(492);
			pro.dejardeMover();
		}
		if(g==JOptionPane.NO_OPTION) {
			System.exit(ABORT);
		}
		if(g==JOptionPane.CANCEL_OPTION) {
			System.exit(ABORT);
		}
	}
}
//creamos una clase que extiende de KeyAdapter, para no tener que definir todos los m�todos de la interface KeyListener. El metodo keyPressed() se ejecutara cada vez que presionamos una tecla.
private class teclado extends KeyAdapter{
	public void keyPressed(KeyEvent e) {
		pro.keyPressed(e);
	}
	public void keyReleased(KeyEvent e) {
		pro.keyReleased(e);
	}
}


}



