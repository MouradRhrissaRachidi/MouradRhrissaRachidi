package CovidGame;

import javax.swing.JSlider;
import javax.swing.SwingConstants;

public interface DatosGenerales {
// Datos que he usado tanto en la clase covids, sliders,juego, protagonista. Tambi�n se pod�a hacer mediante una clase abstracta pero java no permite la herencia m�ltiple, y he tenido que usar una interface
covids covs=new covids();
protagonista pro=new protagonista();
escalera1 esc1=new escalera1();
escalera2 esc2=new escalera2();
background fondo=new background();
vacuna vac=new vacuna();
//creamos los sliders de forma horizontal, empezando de 0 y terminando en 10, con un valor inicial de 0
JSlider bSlider = new JSlider(JSlider.HORIZONTAL, 0, 10, 0);
JSlider gSlider = new JSlider(JSlider.HORIZONTAL, 0, 10, 0);
JSlider rSlider = new JSlider(JSlider.HORIZONTAL, 0, 10, 0);
}