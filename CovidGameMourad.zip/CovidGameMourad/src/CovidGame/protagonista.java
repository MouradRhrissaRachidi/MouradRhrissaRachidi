package CovidGame;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.*;

	public class protagonista extends JPanel implements DatosGenerales {
		//creamos variable de tipo imagen
		private Image imagen;
		private int dx,dy;
		private int x,y;
		public protagonista() {
			//la clase File direcci�n donde se encuentra la im�gen
		File miimagen =new File("src/prota.png");
		try {
			// Image IO=para rescatar im�genes que se encuentran fuera de nuestro programa
		imagen=ImageIO.read(miimagen);
		}
		//si ImageIO no pudo rescatar la im�gen, entonces saltar� una excepci�n del tipo IOException
		catch(IOException e) {
			System.out.println("no se encontr� la imagen prota.png");
		}
		x=5;
		y=492;
		}
		//m�todo que nos permite dibujar la im�gen
	public void paint(Graphics2D g) {
		super.paintComponents(g);
		g.drawImage(imagen,x,y,null);
	}
	//el m�todo KeyPressed nos dice cuando se presiona una tecla, en nuestro caso se mover� cuando se presionan las teclas "A","D","W" o "S"
	public void keyPressed(KeyEvent e) {
		int key=e.getKeyCode();
		//creamos los rect�ngulos, invocanco sus respectivos m�todos
		Rectangle player=pro.getBoundsProtagonista();
		Rectangle escalera2=esc2.getBoundsEscalera2();
		Rectangle escalera1=esc1.getBoundsEscalera1();
		if(key==KeyEvent.VK_A) {
			dx=-2;
		}
		if(key==KeyEvent.VK_D) {
			dx=2;
		}
		if(player.intersects(escalera2)||player.intersects(escalera1)){
		if(key==KeyEvent.VK_A) {
			dx=-1;
		}
		if(key==KeyEvent.VK_D) {
			dx=1;
		}
		if(key==KeyEvent.VK_W) {
			dy=-1;
		}
		if(key==KeyEvent.VK_S) {
			dy=1;
		}
		}
		
	}
	//El m�todo keyReleased nos dice cu�ndo se ha dejado de presionar una tecla(se libera)
	public void keyReleased(KeyEvent e) {
	int key=e.getKeyCode();
	if(key==KeyEvent.VK_A) {
		dx=0;
	}
	if(key==KeyEvent.VK_D) {
		dx=0;
	}
	if(key==KeyEvent.VK_W) {
		dy=0;
	}
	if(key==KeyEvent.VK_S) {
		dy=0;
	}
	}
	//el m�todo keyTyped no lo vamos a usar en nuestro programa, pero hay que ponerlo para que no nos de errores
	public void keyTyped(KeyEvent e) {}
	public int getX() {
		return x;
	}
	public int getY() {
		return y;
	}
	public void mover() {
		x+=dx;
		y+=dy;
	}
	//creamos un rect�ngulo con las dimensiones del protagonista
	public Rectangle getBoundsProtagonista() {
		return new Rectangle(x,y,imagen.getWidth(null),imagen.getHeight(null));
		}
	
	public void setX(int x) {
		this.x=x;
	}
	public void setY(int y) {
		this.y=y;
	}
	//este m�todo lo he puesto ya que cu�ndo el protagonista pierde y quiere jugar otra partida, el protagonista sigue movi�ndose
	public void dejardeMover() {
		dx=0;
		dy=0;
	}
	}



